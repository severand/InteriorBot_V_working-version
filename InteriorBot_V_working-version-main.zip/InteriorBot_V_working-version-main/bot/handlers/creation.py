# bot/handlers/creation.py
# --- UPDATED: 2025-12-23 08:36 - ONLY NANO BANANA ---
# [2025-12-07 11:09] CRITICAL: Deleted duplicate function show_single_menu() - using edit_menu() from utils/navigation.py
# [2025-12-07 11:09] Added screen_code to all edit_menu() calls
# [2025-12-07 11:09] Replaced go_to_main_menu with show_main_menu() from navigation.py
# [2025-12-07 11:09] All transitions use unified navigation system
# [2025-12-06] Markdown/HTML layout fixes, safe signatures

import asyncio
import logging
import html

from aiogram import Router, F
from aiogram.enums import ParseMode
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message, URLInputFile
from aiogram.exceptions import TelegramBadRequest

from database.db import db

from keyboards.inline import (
    get_room_keyboard,
    get_style_keyboard,
    get_payment_keyboard,
    get_post_generation_keyboard,
    get_upload_photo_keyboard,
    get_what_is_in_photo_keyboard
)

from services.replicate_api import (
    generate_image_auto,
    clear_space_image,
    generate_with_text_prompt
)

# Nano Banana API и конфигурация
from config_kie import config_kie
from services.kie_api import (
    generate_interior_with_nano_banana,
    clear_space_with_kie,
)

from states.fsm import CreationStates

from utils.texts import (
    CHOOSE_STYLE_TEXT,
    PHOTO_SAVED_TEXT,
    NO_BALANCE_TEXT,
    TOO_MANY_PHOTOS_TEXT,
    UPLOAD_PHOTO_TEXT,
    WHAT_IS_IN_PHOTO_TEXT,
    EXTERIOR_HOUSE_PROMPT_TEXT,
    EXTERIOR_PLOT_PROMPT_TEXT,
    ROOM_DESCRIPTION_PROMPT_TEXT
)

from utils.navigation import edit_menu, show_main_menu

logger = logging.getLogger(__name__)
router = Router()


# ===== HELPER FUNCTION FOR INTERIOR GENERATION =====

async def generate_interior_design(
    photo_file_id: str,
    room: str,
    style: str,
    bot_token: str,
) -> str | None:
    """
    Генерация дизайна интерьера на Nano Banana.

    Args:
        photo_file_id: ID фото из Telegram
        room: Тип комнаты
        style: Стиль дизайна
        bot_token: Токен телеграм бота

    Returns:
        URL сгенерированного изображения или None
    """
    if config_kie.USE_KIE_API:
        # Пытаемся с Nano Banana
        result = await generate_interior_with_nano_banana(
            photo_file_id=photo_file_id,
            room=room,
            style=style,
            bot_token=bot_token,
        )

        # Fallback к Replicate, если Nano Banana не работает
        if result is None and config_kie.KIE_FALLBACK_TO_REPLICATE:
            logger.info("🔄 Nano Banana недоступен, используем Replicate...")
            result = await generate_image_auto(
                photo_file_id=photo_file_id,
                room=room,
                style=style,
                bot_token=bot_token,
            )
        
        return result
    else:
        # Используем Replicate
        return await generate_image_auto(
            photo_file_id=photo_file_id,
            room=room,
            style=style,
            bot_token=bot_token,
        )


# ===== MAIN MENU AND START =====
@router.callback_query(F.data == "main_menu")
async def go_to_main_menu(callback: CallbackQuery, state: FSMContext, admins: list[int]):
    """Возврат в главное меню"""
    user_id = callback.from_user.id
    await db.log_activity(user_id, 'main_menu')

    await show_main_menu(callback, state, admins)
    await callback.answer()


@router.callback_query(F.data == "create_design")
async def choose_new_photo(callback: CallbackQuery, state: FSMContext):
    """Начало создания дизайна"""
    user_id = callback.from_user.id
    await db.log_activity(user_id, 'create_design')

    data = await state.get_data()
    menu_message_id = data.get('menu_message_id')

    await state.clear()

    if menu_message_id:
        await state.update_data(menu_message_id=menu_message_id)

    await state.set_state(CreationStates.waiting_for_photo)

    await edit_menu(
        callback=callback,
        state=state,
        text=UPLOAD_PHOTO_TEXT,
        keyboard=get_upload_photo_keyboard(),
        screen_code='upload_photo'
    )
    await callback.answer()


# ===== PHOTO UPLOAD HANDLER =====
@router.message(CreationStates.waiting_for_photo, F.photo)
async def photo_uploaded(message: Message, state: FSMContext, admins: list[int]):
    """Обработка загруженного фото"""
    user_id = message.from_user.id
    await db.log_activity(user_id, 'photo_upload')

    if message.media_group_id:
        data = await state.get_data()
        cached_group_id = data.get('media_group_id')
        try:
            await message.delete()
        except Exception:
            pass
        if cached_group_id != message.media_group_id:
            await state.update_data(media_group_id=message.media_group_id)
            msg = await message.answer(TOO_MANY_PHOTOS_TEXT)
            await asyncio.sleep(3)
            try:
                await msg.delete()
            except Exception:
                pass
        return

    await state.update_data(media_group_id=None)
    photo_file_id = message.photo[-1].file_id

    if user_id not in admins:
        balance = await db.get_balance(user_id)
        if balance <= 0:
            await state.clear()
            menu_msg = await message.answer(
                NO_BALANCE_TEXT,
                reply_markup=get_payment_keyboard(),
                parse_mode="Markdown"
            )
            await state.update_data(menu_message_id=menu_msg.message_id)
            chat_id = message.chat.id
            await db.save_chat_menu(chat_id, user_id, menu_msg.message_id, 'no_balance')
            return

    await state.update_data(photo_id=photo_file_id)
    await state.update_data(scene_type=None, room=None, style=None, exterior_prompt=None, room_description=None)
    await state.set_state(CreationStates.what_is_in_photo)

    data = await state.get_data()
    old_menu_id = data.get('menu_message_id')
    if old_menu_id:
        try:
            await message.bot.delete_message(
                chat_id=message.chat.id,
                message_id=old_menu_id
            )
        except Exception as e:
            logger.debug(f"Не удалось удалить старое меню: {e}")

    from utils.helpers import add_balance_to_text
    text_with_balance = await add_balance_to_text(WHAT_IS_IN_PHOTO_TEXT, user_id)

    sent_msg = await message.answer(
        text=text_with_balance,
        reply_markup=get_what_is_in_photo_keyboard(),
        parse_mode="Markdown"
    )

    await state.update_data(menu_message_id=sent_msg.message_id)
    await db.save_chat_menu(message.chat.id, user_id, sent_msg.message_id, 'what_is_in_photo')


# ===== SCENE TYPE SELECTION =====
@router.callback_query(CreationStates.what_is_in_photo, F.data.startswith("scene_"))
async def exterior_scene_chosen(callback: CallbackQuery, state: FSMContext):
    """Выбран экстерьер"""
    scene_type = callback.data.replace("scene_", "")
    user_id = callback.from_user.id

    await db.log_activity(user_id, f'scene_{scene_type}')

    await state.update_data(scene_type=scene_type, room=None)
    await state.set_state(CreationStates.waiting_for_exterior_prompt)

    if scene_type == "house_exterior":
        prompt_text = EXTERIOR_HOUSE_PROMPT_TEXT
    else:
        prompt_text = EXTERIOR_PLOT_PROMPT_TEXT

    await edit_menu(
        callback=callback,
        state=state,
        text=prompt_text,
        keyboard=get_upload_photo_keyboard(),
        screen_code='exterior_prompt'
    )
    await callback.answer()


@router.callback_query(CreationStates.what_is_in_photo, F.data.startswith("room_"))
async def interior_room_chosen(callback: CallbackQuery, state: FSMContext, admins: list[int]):
    """Выбран интерьер (комната)"""
    room = callback.data.replace("room_", "")
    user_id = callback.from_user.id

    await db.log_activity(user_id, f'room_{room}')

    if user_id not in admins:
        balance = await db.get_balance(user_id)
        if balance <= 0:
            await state.clear()
            await edit_menu(
                callback=callback,
                state=state,
                text=NO_BALANCE_TEXT,
                keyboard=get_payment_keyboard(),
                screen_code='no_balance'
            )
            return

    if room == "other":
        await state.update_data(scene_type="interior", room="other_room")
        await state.set_state(CreationStates.waiting_for_room_description)

        await edit_menu(
            callback=callback,
            state=state,
            text=ROOM_DESCRIPTION_PROMPT_TEXT,
            keyboard=get_upload_photo_keyboard(),
            screen_code='room_description'
        )
        await callback.answer()
        return

    await state.update_data(scene_type="interior", room=room)
    await state.set_state(CreationStates.choose_style)

    await edit_menu(
        callback=callback,
        state=state,
        text=CHOOSE_STYLE_TEXT,
        keyboard=get_style_keyboard(),
        screen_code='choose_style'
    )
    await callback.answer()


# ===== TEXT PROMPT INPUT FOR EXTERIOR =====
@router.message(CreationStates.waiting_for_exterior_prompt, F.text)
async def exterior_prompt_received(message: Message, state: FSMContext, admins: list[int], bot_token: str):
    """Получен текстовый промпт для экстерьера"""
    user_prompt = message.text.strip()
    user_id = message.from_user.id
    chat_id = message.chat.id

    if len(user_prompt) < 5:
        msg = await message.answer("⚠️ Опишите подробнее (минимум 5 символов)")
        await asyncio.sleep(3)
        try:
            await msg.delete()
            await message.delete()
        except:
            pass
        return

    data = await state.get_data()
    photo_id = data.get('photo_id')
    scene_type = data.get('scene_type', 'custom')

    if not photo_id:
        await message.answer("⚠️ Сессия устарела. Загрузите фото заново.")
        await state.clear()
        return

    await state.update_data(exterior_prompt=user_prompt)

    try:
        await message.delete()
    except:
        pass

    is_admin = user_id in admins
    if not is_admin:
        balance = await db.get_balance(user_id)
        if balance <= 0:
            await state.clear()
            data = await state.get_data()
            menu_id = data.get('menu_message_id')
            if menu_id:
                try:
                    await message.bot.edit_message_text(
                        chat_id=chat_id,
                        message_id=menu_id,
                        text=NO_BALANCE_TEXT,
                        reply_markup=get_payment_keyboard(),
                        parse_mode="Markdown"
                    )
                except:
                    pass
            return

    if not is_admin:
        await db.decrease_balance(user_id)

    data = await state.get_data()
    menu_id = data.get('menu_message_id')
    if menu_id:
        try:
            await message.bot.edit_message_text(
                chat_id=chat_id,
                message_id=menu_id,
                text=" ⏳ Создаю дизайн экстерьера...",
            )
        except:
            pass

    try:
        result_image_url = await generate_with_text_prompt(
            photo_id,
            user_prompt,
            bot_token,
            scene_type=scene_type
        )
        success = result_image_url is not None
    except Exception as e:
        logger.error(f"Критическая ошибка: {e}")
        result_image_url = None
        success = False

    await db.log_generation(
        user_id=user_id,
        room_type=scene_type,
        style_type='text_prompt',
        operation_type='exterior',
        success=success
    )

    if result_image_url:
        scene_name = "дома" if scene_type == "house_exterior" else "участка"
        caption = (
            f"✨ Ваш новый дизайн {scene_name}!\n\n"
            f"Ваше задание: {user_prompt}"
        )

        sent_photo_message = None
        try:
            sent_photo_message = await message.answer_photo(
                photo=result_image_url,
                caption=caption,
                parse_mode="HTML"
            )
        except Exception as e:
            logger.error(f"Ошибка отправки: {e}")

            import aiohttp
            from aiogram.types import BufferedInputFile

            try:
                async with aiohttp.ClientSession() as session:
                    async with session.get(result_image_url, timeout=aiohttp.ClientTimeout(total=20)) as resp:
                        if resp.status == 200:
                            photo_data = await resp.read()
                            sent_photo_message = await message.answer_photo(
                                photo=BufferedInputFile(photo_data, filename="room.jpg"),
                                caption=caption,
                                parse_mode="HTML"
                            )
            except Exception as fallback_error:
                logger.error(f"Ошибка: {fallback_error}")

                if menu_id:
                    try:
                        await message.bot.edit_message_text(
                            chat_id=chat_id,
                            message_id=menu_id,
                            text="❌ Ошибка при отправке. Попытайте ещё.",
                            reply_markup=get_payment_keyboard(),
                            parse_mode="Markdown"
                        )
                    except:
                        pass
                return

        if sent_photo_message and sent_photo_message.photo:
            new_photo_id = sent_photo_message.photo[-1].file_id
            await state.update_data(photo_id=new_photo_id)

        if menu_id:
            try:
                await message.bot.delete_message(chat_id=chat_id, message_id=menu_id)
                await db.delete_chat_menu(chat_id)
            except:
                pass

        from utils.helpers import add_balance_to_text
        text_with_balance = await add_balance_to_text("✅ Выбери что дальше а️", user_id)

        new_menu = await message.answer(
            text=text_with_balance,
            reply_markup=get_post_generation_keyboard(show_continue_editing=True),
            parse_mode="Markdown"
        )

        await state.update_data(menu_message_id=new_menu.message_id)
        await db.save_chat_menu(chat_id, user_id, new_menu.message_id, 'post_generation')

    else:
        from keyboards.inline import get_main_menu_keyboard
        if menu_id:
            try:
                await message.bot.edit_message_text(
                    chat_id=chat_id,
                    message_id=menu_id,
                    text="❌ Ошибка генерации. Попытайте ещё.",
                    reply_markup=get_main_menu_keyboard(is_admin=is_admin),
                    parse_mode="Markdown"
                )
            except:
                pass
