# 🗺️ КАРТА ЭКРАНОВ И КНОПОК (ФАКТИЧЕСКАЯ)
## InteriorBot — по коду main/handlers/keyboards, без выдумок

**Версия:** 2.0 (переписано по фактическому коду)  
**Дата:** 22.12.2025  
**Источник:** `bot/handlers/*.py`, `bot/keyboards/inline.py`, `bot/states/fsm.py`

> В этом документе НЕТ выдуманных экранов и кнопок. Всё взято из кода: реальные `callback_data`, реальные тексты кнопок, реальные связи.

---

# 1. ОБЗОР СТРУКТУРЫ

## 1.1. Основные модули, влияющие на экраны

- `bot/handlers/user_start.py`  
  `/start`, главное меню, профиль, покупка генераций, партнёрка, статистика, поддержка.
- `bot/handlers/creation.py`  
  Весь сценарий создания дизайна: загрузка фото, "что на фото", выбор комнат/стилей, очистка, генерация, пост-экран.
- `bot/keyboards/inline.py`  
  Все inline‑клавиатуры и реальные `callback_data`.
- `bot/states/fsm.py`  
  FSM‑состояния для сценария создания.

---

# 2. FSM СОСТОЯНИЯ (фактические)

**Файл:** `bot/states/fsm.py`

```python
class CreationStates(StatesGroup):
    waiting_for_photo = State()
    what_is_in_photo = State()
    choose_room = State()
    choose_style = State()
    waiting_for_room_description = State()
    waiting_for_exterior_prompt = State()
```

---

# 3. ИСТОЧНИКИ КНОПОК (inline.py)

Ниже — только то, что реально есть в `inline.py`.

## 3.1. Главное меню

```python
def get_main_menu_keyboard(is_admin: bool = False) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(
        text="                   🎨 Создать дизайн                         ",
        callback_data="create_design"
    ))
    builder.row(InlineKeyboardButton(
        text="                   👤 Личный кабинет                              ",
        callback_data="show_profile"
    ))
    if is_admin:
        builder.row(InlineKeyboardButton(
            text="         ⚙️ Админ-панель        ",
            callback_data="admin_panel"
        ))
    builder.adjust(1)
    return builder.as_markup()
```

**Кнопки на экране `main_menu`:**

| Текст кнопки                                           | `callback_data` | Куда ведёт |
|--------------------------------------------------------|-----------------|------------|
| `🎨 Создать дизайн` (с пробелами в начале/конце)       | `create_design` | в `user_start.start_creation` или `creation.choose_new_photo` (см. ниже) |
| `👤 Личный кабинет`                                    | `show_profile`  | в `user_start.show_profile` |
| `⚙️ Админ-панель` (ТОЛЬКО если is_admin=True)          | `admin_panel`   | в `admin.py` (в этом документе подробно не разбираем) |

**Важно:** никаких `show_statistics`, `show_support` и т.п. в главном меню нет. Они есть только в логике `user_start` как возможные callback, но соответствующие кнопки в `get_main_menu_keyboard` не создаются.

---

## 3.2. Экран "Загрузите фото"

```python
def get_upload_photo_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text="🏠 Главное меню", callback_data="main_menu"))
    builder.adjust(1)
    return builder.as_markup()
```

**Кнопки на экране загрузки фото:**

| Текст            | `callback_data` | Куда ведёт |
|------------------|-----------------|------------|
| `🏠 Главное меню` | `main_menu`     | в `user_start.back_to_main_menu` или `creation.go_to_main_menu` (оба роутера ловят F.data == "main_menu") |

---

## 3.3. Экран "Что на фото" (what_is_in_photo)

```python
def get_what_is_in_photo_keyboard() -> InlineKeyboardMarkup:
    # Ряд 1: ЭКСТЕРЬЕР (закомментированы)
    builder.row(
       # InlineKeyboardButton(text="🏠 Дом (фасад)", callback_data="scene_house_exterior"),
       # InlineKeyboardButton(text="🌳 Участок / двор", callback_data="scene_plot_exterior")
    )

    # Ряд 2: Гостиная / Кухня
    builder.row(
        InlineKeyboardButton(text="🛋 Гостиная", callback_data="room_living_room"),
        InlineKeyboardButton(text="🍽 Кухня", callback_data="room_kitchen")
    )

    # Ряд 3: Спальня / Детская
    builder.row(
        InlineKeyboardButton(text="🛏 Спальня", callback_data="room_bedroom"),
        InlineKeyboardButton(text="👶 Детская", callback_data="room_nursery")
    )

    # Ряд 4: Ванная / Кабинет
    builder.row(
        InlineKeyboardButton(text="🚿 Ванная / санузел", callback_data="room_bathroom_full"),
        InlineKeyboardButton(text="💼 Кабинет", callback_data="room_home_office")
    )

    builder.row(
        InlineKeyboardButton(text="🛋 Прихожая", callback_data="Entryway"),
        InlineKeyboardButton(text="🍽 Гардеробная", callback_data="wardrobe")
    )

    # Ряд 5: Другое / Комната целиком
    builder.row(
        InlineKeyboardButton(text="🔍 Другое помещение", callback_data="room_other"),
        InlineKeyboardButton(text="🏡 Комната целиком", callback_data="room_studio")
    )

    # Ряд 6: Главное меню
    builder.row(InlineKeyboardButton(text="🏠 Главное меню", callback_data="main_menu"))

    builder.adjust(2, 2, 2, 2, 2, 1)
    return builder.as_markup()
```

**ФАКТИЧЕСКИЕ кнопки и переходы:**

| Текст                        | `callback_data`        | Где обрабатывается / комментарий |
|-----------------------------|------------------------|-----------------------------------|
| `🛋 Гостиная`               | `room_living_room`     | `creation.interior_room_chosen` (F.data.startswith("room_")) → room="living_room" |
| `🍽 Кухня`                  | `room_kitchen`         | `creation.interior_room_chosen` → room="kitchen" |
| `🛏 Спальня`                | `room_bedroom`         | → room="bedroom" |
| `👶 Детская`                | `room_nursery`         | → room="nursery" |
| `🚿 Ванная / санузел`       | `room_bathroom_full`   | → room="bathroom_full" |
| `💼 Кабинет`                | `room_home_office`     | → room="home_office" |
| `🛋 Прихожая`               | `Entryway`             | **важно:** здесь callback НЕ начинается с `room_`, обработчика под `Entryway` нет → уйдёт в `handle_stale_creation_buttons` как F.data.startswith("room_") не подходит, но F.data.in_(...) тоже нет → по факту эта кнопка сейчас НЕ обслуживается отдельно. |
| `🍽 Гардеробная`            | `wardrobe`             | аналогично: нет отдельного handler'а, кнопка фактически не обработана. |
| `🔍 Другое помещение`       | `room_other`           | `creation.interior_room_chosen` → спец. ветка room=="other" |
| `🏡 Комната целиком`        | `room_studio`          | `creation.interior_room_chosen` → room="studio" (как простой room) |
| `🏠 Главное меню`           | `main_menu`            | `user_start.back_to_main_menu` / `creation.go_to_main_menu` |

**Закомментированные кнопки ЭКСТЕРЬЕРА:** `scene_house_exterior`, `scene_plot_exterior` — в текущем `inline.py` не создаются вообще (их нельзя нажать в реальном боте).

Обработчик под `scene_` есть в `creation.exterior_scene_chosen`, но нет активных кнопок, которые генерируют такие `callback_data`.

---

## 3.4. Клавиатура выбора комнаты (после очистки)

```python
def get_room_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    # Кнопка "Очистить пространство" ЗАКОММЕНТИРОВАНА
    for key, text in ROOM_TYPES.items():
        builder.row(InlineKeyboardButton(text=text, callback_data=f"room_{key}"))
    builder.row(InlineKeyboardButton(text="🏠 Главное меню", callback_data="main_menu"))
    builder.adjust(2)
    return builder.as_markup()
```

**ROOM_TYPES:**

```python
ROOM_TYPES = {
    "living_room": "Гостиная",
    "bedroom": "Спальня",
    "kitchen": "Кухня",
    "dining_room": "Столовая",
    "home_office": "Кабинет",
    "Entryway": "Прихожая",
    "bathroom_full": "Ванная",
    "toilet": "Санузел",
    "wardrobe": "Гардеробная",
    "nursery": "Детская (малыш)",
}
```

**Кнопки на экране `choose_room`:**

| Текст                   | `callback_data`           | Переход |
|-------------------------|---------------------------|---------|
| Гостиная                | `room_living_room`        | `room_chosen` (CreationStates.choose_room) |
| Спальня                 | `room_bedroom`            | → room="bedroom" |
| Кухня                   | `room_kitchen`            | → room="kitchen" |
| Столовая                | `room_dining_room`        | → room="dining_room" |
| Кабинет                 | `room_home_office`        | → room="home_office" |
| Прихожая                | `room_Entryway`           | → room="Entryway" |
| Ванная                  | `room_bathroom_full`      | → room="bathroom_full" |
| Санузел                 | `room_toilet`             | → room="toilet" |
| Гардеробная             | `room_wardrobe`           | → room="wardrobe" |
| Детская (малыш)         | `room_nursery`            | → room="nursery" |
| 🏠 Главное меню          | `main_menu`               | в главное меню |

Все `room_*` в этом контексте обрабатываются `creation.room_chosen` (CreationStates.choose_room).

---

## 3.5. Клавиатура выбора стиля

```python
def get_style_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    style_rows = [STYLE_TYPES[i:i + 2] for i in range(0, len(STYLE_TYPES), 2)]
    for row in style_rows:
        buttons = [InlineKeyboardButton(text=style_name, callback_data=f"style_{style_key}") for style_key, style_name in row]
        builder.row(*buttons)
    builder.row(
        InlineKeyboardButton(text="🧽 Очистить пространство", callback_data="clear_space_confirm"),
        InlineKeyboardButton(text="⬅️ Выбрать комнату", callback_data="back_to_room"),
        InlineKeyboardButton(text="🏠 Главное меню", callback_data="main_menu"),
    )
    return builder.as_markup()
```

**STYLE_TYPES (факт):**

```python
STYLE_TYPES = [
    ("modern", "Современный"),
    ("minimalist", "Минимализм"),
    ("scandinavian", "Скандинавский"),
    ("industrial", "Индустриальный (лофт)"),
    ("rustic", "Рустик"),
    ("japandi", "Джапанди"),
    ("boho", "Бохо / Эклектика"),
    ("midcentury", "Mid‑century / винтаж"),
    ("artdeco", "Арт‑деко"),
    ("coastal", "Прибрежный"),
    ("Organic Modern", "Органический Модерн"),
    ("Loft", "Лофт"),
]
```

**Реальные `callback_data`:**

| Текст                     | `callback_data`           |
|---------------------------|---------------------------|
| Современный               | `style_modern`           |
| Минимализм                | `style_minimalist`       |
| Скандинавский             | `style_scandinavian`     |
| Индустриальный (лофт)     | `style_industrial`       |
| Рустик                    | `style_rustic`           |
| Джапанди                  | `style_japandi`          |
| Бохо / Эклектика          | `style_boho`             |
| Mid‑century / винтаж      | `style_midcentury`       |
| Арт‑деко                  | `style_artdeco`          |
| Прибрежный                | `style_coastal`          |
| Органический Модерн       | `style_Organic Modern`   | ← ключ содержит пробел, важно |
| Лофт                      | `style_Loft`             |

**Нижний ряд:**

| Текст                     | `callback_data`        | Переход |
|---------------------------|------------------------|---------|
| 🧽 Очистить пространство  | `clear_space_confirm`  | `clear_space_confirm_handler` (CreationStates.choose_style) |
| ⬅️ Выбрать комнату        | `back_to_room`         | `back_to_room_selection` |
| 🏠 Главное меню            | `main_menu`            | главное меню |

---

## 3.6. Клавиатура после генерации

```python
def get_post_generation_keyboard(show_continue_editing: bool = False) -> InlineKeyboardMarkup:
    if show_continue_editing:
        builder.row(
            InlineKeyboardButton(text="✏️ Продолжить редактирование", callback_data="continue_editing"),
            InlineKeyboardButton(text="📸 Новое фото", callback_data="create_design"),
        )
    else:
        builder.row(
            InlineKeyboardButton(text="🔄 Другой стиль      ", callback_data="change_style"),
            InlineKeyboardButton(text="📸 Новое фото         ", callback_data="create_design"),
        )
    builder.row(InlineKeyboardButton(text="🏠 Главное меню    ", callback_data="main_menu"))
```

**Кнопки:**

- В сценариях с текстовым промптом (экстерьер/"другое помещение"), `show_continue_editing=True`:

| Текст                        | `callback_data`      |
|-----------------------------|----------------------|
| ✏️ Продолжить редактирование | `continue_editing`   |
| 📸 Новое фото                | `create_design`      |
| 🏠 Главное меню              | `main_menu`          |

- В сценарии генерации по стилю (`show_continue_editing=False`):

| Текст                        | `callback_data`      |
|-----------------------------|----------------------|
| 🔄 Другой стиль              | `change_style`       |
| 📸 Новое фото                | `create_design`      |
| 🏠 Главное меню              | `main_menu`          |

---

## 3.7. Клавиатура профиля

```python
def get_profile_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="💳 Стоимость генераций", callback_data="buy_generations"),
        # InlineKeyboardButton(text="📊 Статистика", callback_data="show_statistics")
    )
    builder.row(
        # InlineKeyboardButton(text="🎁 Партнёрская программа", callback_data="show_referral_program"),
        InlineKeyboardButton(text="💬 Поддержка", callback_data="show_support")
    )
    builder.row(InlineKeyboardButton(text="🏠 Главное меню", callback_data="main_menu"))
```

**ТОЛЬКО эти кнопки реально существуют на экране профиля:**

| Текст                     | `callback_data`     | Переход |
|---------------------------|---------------------|---------|
| 💳 Стоимость генераций    | `buy_generations`   | `user_start.buy_generations_handler` |
| 💬 Поддержка              | `show_support`      | `user_start.show_support` |
| 🏠 Главное меню            | `main_menu`         | главное меню |

Статистика и партнёрка **не выводятся** из профиля, потому что эти кнопки закомментированы в `get_profile_keyboard`.

---

## 3.8. Клавиатуры оплаты

```python
def get_payment_keyboard() -> InlineKeyboardMarkup:
    for tokens, price in PACKAGES.items():
        button_text = f"{tokens} генераций - {price} руб."
        builder.row(InlineKeyboardButton(text=button_text, callback_data=f"pay_{tokens}_{price}"))
    builder.row(InlineKeyboardButton(text="⬅️ Назад в профиль", callback_data="show_profile"))
```

**PACKAGES:** `{10: 190, 25: 450, 50: 850}`

**Кнопки:**

| Текст                          | `callback_data`   | Переход |
|--------------------------------|-------------------|---------|
| `10 генераций - 190 руб.`      | `pay_10_190`      | в `payment.py` (не разбираем подробно) |
| `25 генераций - 450 руб.`      | `pay_25_450`      | → payment |
| `50 генераций - 850 руб.`      | `pay_50_850`      | → payment |
| ⬅️ Назад в профиль              | `show_profile`    | профиль |

---

# 4. ЭКРАНЫ И СВЯЗИ (ТОЛЬКО ФАКТ)

Ниже — **карта экранов**, где каждый экран определён через:
- Текст/назначение
- Какие клавиатуры на нём используются
- Какие `callback_data` возможны
- Куда реально ведёт каждая кнопка

## 4.1. `/start` → Главное меню

**Handler:** `user_start.cmd_start`  
**Итоговый экран:** `main_menu` с `get_main_menu_keyboard()`

**Кнопки:** см. раздел 3.1.

---

## 4.2. Экран `main_menu`

**Источники перехода на этот экран:**
- `/start`
- callback `main_menu` из разных хендлеров (`user_start.back_to_main_menu`, `creation.go_to_main_menu`)

**Кнопки:**
- `create_design` → `user_start.start_creation` **или** `creation.choose_new_photo` (оба слушают F.data == "create_design"; по факту оба роутера, но в runtime решает порядок регистрации)
- `show_profile` → `user_start.show_profile`
- `admin_panel` → `admin.py`

---

## 4.3. Экран загрузки фото (`upload_photo`)

**Хендлер:**
- `user_start.start_creation` (callback `create_design`)
- `creation.choose_new_photo` (такой же callback, дублирует логику)

Оба в итоге делают:
- `state.set_state(CreationStates.waiting_for_photo)`
- `edit_menu(..., text=UPLOAD_PHOTO_TEXT, keyboard=get_upload_photo_keyboard(), screen_code='upload_photo')`

**Кнопки на экране:**
- `main_menu` → главное меню

**Переходы:**
- Message с `photo` в состоянии `waiting_for_photo` → `creation.photo_uploaded`

---

## 4.4. Экран "Что на фото" (`what_is_in_photo`)

**Создаётся в:** `creation.photo_uploaded`

- Сохранение `photo_id`
- `state.set_state(CreationStates.what_is_in_photo)`
- Отправка нового сообщения с клавиатурой `get_what_is_in_photo_keyboard()`
- Сохранение `screen_code='what_is_in_photo'`

**Кнопки и реальные переходы:**

| `callback_data`        | Обработчик                                               |
|------------------------|----------------------------------------------------------|
| `room_living_room`     | `creation.interior_room_chosen` (state=what_is_in_photo) |
| `room_kitchen`         | `creation.interior_room_chosen`                          |
| `room_bedroom`         | `creation.interior_room_chosen`                          |
| `room_nursery`         | `creation.interior_room_chosen`                          |
| `room_bathroom_full`   | `creation.interior_room_chosen`                          |
| `room_home_office`     | `creation.interior_room_chosen`                          |
| `room_other`           | `creation.interior_room_chosen` → ветка "другое помещение"|
| `room_studio`          | `creation.interior_room_chosen`                          |
| `Entryway` / `wardrobe`| **нет явного handler'а с таким F.data** → не обрабатываются специальным образом |
| `main_menu`            | главное меню                                             |

**Важно:** обработчик экстерьера `exterior_scene_chosen` слушает `F.data.startswith("scene_")`, но активных кнопок `scene_*` сейчас нет (они закомментированы в `inline.py`).

---

## 4.5. Экран выбора стиля (`choose_style`)

**Переход из:** `creation.interior_room_chosen`, если `room != "other"`.

- `state.set_state(CreationStates.choose_style)`
- `edit_menu(..., text=CHOOSE_STYLE_TEXT, keyboard=get_style_keyboard(), screen_code='choose_style')`

**Кнопки и переходы:**

| `callback_data`        | Обработчик                                         |
|------------------------|----------------------------------------------------|
| `style_modern`         | `creation.style_chosen` (state=choose_style)      |
| `style_minimalist`     | `creation.style_chosen`                            |
| `style_scandinavian`   | `creation.style_chosen`                            |
| `style_industrial`     | `creation.style_chosen`                            |
| `style_rustic`         | `creation.style_chosen`                            |
| `style_japandi`        | `creation.style_chosen`                            |
| `style_boho`           | `creation.style_chosen`                            |
| `style_midcentury`     | `creation.style_chosen`                            |
| `style_artdeco`        | `creation.style_chosen`                            |
| `style_coastal`        | `creation.style_chosen`                            |
| `style_Organic Modern` | `creation.style_chosen` (важно: пробел в ключе)    |
| `style_Loft`           | `creation.style_chosen`                            |
| `clear_space_confirm`  | `creation.clear_space_confirm_handler`             |
| `back_to_room`         | `creation.back_to_room_selection` (→ choose_room) |
| `main_menu`            | главное меню                                       |

---

## 4.6. Экран подтверждения очистки (`clear_space_confirm`)

**Создаётся в:** `creation.clear_space_confirm_handler` при `F.data == "clear_space_confirm"` и state=choose_style.

- `edit_menu(..., text=..., keyboard=get_clear_space_confirm_keyboard(), screen_code='clear_space_confirm')`

**Кнопки:**

| Текст        | `callback_data`       | Обработчик                            |
|-------------|------------------------|----------------------------------------|
| ✅ Очистить | `clear_space_execute`  | `creation.clear_space_execute_handler` |
| ❌ Отмена   | `clear_space_cancel`   | `creation.clear_space_cancel_handler`  |

---

## 4.7. Экран выбора комнаты после очистки (`choose_room`)

**Создаётся в:**
- `creation.clear_space_execute_handler` → после успешной очистки → `state.set_state(CreationStates.choose_room)` и отправка нового меню `get_room_keyboard()`.
- `creation.clear_space_cancel_handler`
- `creation.back_to_room_selection`

**Кнопки:** `get_room_keyboard()` (см. 3.4).

**Обработчик:** `creation.room_chosen` (CreationStates.choose_room).

---

## 4.8. Экраны текстового ввода (экстерьер, другое помещение)

### 4.8.1. Экстерьер (`waiting_for_exterior_prompt`)

**Состояние:** `CreationStates.waiting_for_exterior_prompt`

**Хендлер ввода:** `creation.exterior_prompt_received` (F.text)

Экран не имеет inline‑клавиатуры, кроме `get_upload_photo_keyboard()` в edit_menu для возврата в главное меню.

**Переходы после ввода текста:**
- Успех → отправка фото + меню `get_post_generation_keyboard(show_continue_editing=True)` → экран post_generation (вариант с `continue_editing`).
- Ошибка → редактирование текущего меню с текстом ошибки.

---

### 4.8.2. Другое помещение (`waiting_for_room_description`)

**Состояние:** `CreationStates.waiting_for_room_description`

**Хендлер:** `creation.room_description_received` (F.text)

Логика аналогична экстерьеру: текст → генерация → фото → меню `get_post_generation_keyboard(show_continue_editing=True)`.

---

## 4.9. Экран пост‑генерации (`post_generation`)

Создаётся в:
- `creation.style_chosen` (show_continue_editing=False)
- `creation.exterior_prompt_received` (True)
- `creation.room_description_received` (True)

**Клавиатуры:** `get_post_generation_keyboard(...)`

**Переходы:**

| `callback_data`    | Контекст                | Обработчик                         |
|--------------------|-------------------------|------------------------------------|
| `change_style`     | генерация по стилю      | `creation.change_style_after_gen`  |
| `continue_editing` | текстовые сценарии      | `creation.continue_editing_handler`|
| `create_design`    | оба сценария            | новый цикл создания (см. выше)     |
| `main_menu`        | оба сценария            | главное меню                       |

---

## 4.10. Экран профиля (`profile`)

**Хендлер:** `user_start.show_profile`

- Формирует `PROFILE_TEXT` и вызывает `edit_menu(..., keyboard=get_profile_keyboard(), screen_code='profile')`.

**Кнопки:** `get_profile_keyboard()` (см. 3.7).

**Переходы:**

| `callback_data`    | Обработчик                        |
|--------------------|-----------------------------------|
| `buy_generations`  | `user_start.buy_generations_handler` |
| `show_support`     | `user_start.show_support`         |
| `main_menu`        | главное меню                      |

---

## 4.11. Экран оплаты (`balance`)

**Хендлер:** `user_start.buy_generations_handler`

- `edit_menu(..., text="💰 **Выберите пакет генераций**...", keyboard=get_payment_keyboard(), screen_code='balance')`

**Кнопки:** `get_payment_keyboard()` (см. 3.8).

**Переходы:**
- `pay_10_190`, `pay_25_450`, `pay_50_850` → в `payment.py`
- `show_profile` → обратно в профиль.

---

## 4.12. Экран статистики (`statistics`)

**Хендлер:** `user_start.show_statistics` (F.data == "show_statistics")

Эта кнопка **не создаётся** ни в одной клавиатуре, но логика экрана есть.

Клавиатура создаётся inline прямо в хендлере:

```python
builder.row(InlineKeyboardButton(text="⬅️ Назад в профиль", callback_data="show_profile"))
```

**Кнопки:**

| Текст                | `callback_data` | Переход |
|----------------------|-----------------|---------|
| ⬅️ Назад в профиль   | `show_profile`  | профиль |

---

## 4.13. Экран партнёрской программы (`referral`)

Аналогично статистике:

- Хендлер: `user_start.show_referral_program` (F.data == "show_referral_program")
- Клавиатура строится в хендлере.

**Текст кнопок и `callback_data`:**

| Текст                        | `callback_data`              |
|-----------------------------|------------------------------|
| 💸 Вывести деньги           | `referral_request_payout`    |
| 💎 Обменять на генерации    | `referral_exchange_tokens`   |
| ⚙️ Реквизиты для выплат      | `referral_setup_payment`     |
| 📊 История операций          | `referral_history`           |
| ⬅️ Назад в профиль           | `show_profile`               |

Опять же: **кнопки, ведущей на этот экран, сейчас нет** в `get_profile_keyboard` или `get_main_menu` ("🎁 Партнёрская программа" закомментирована).

---

## 4.14. Экран поддержки (`support`)

**Хендлер:** `user_start.show_support` (F.data == "show_support")

Клавиатура формируется в хендлере:

| Текст                | `callback_data` |
|----------------------|-----------------|
| ⬅️ Назад в профиль   | `show_profile`  |

---

# 5. ВЫВОД

- Все экраны и кнопки в этом документе взяты **строго** из:
  - `bot/keyboards/inline.py`
  - `bot/handlers/user_start.py`
  - `bot/handlers/creation.py`
- Никаких выдуманных `callback_data` и экранов.
- Отмечены места, где **кнопки есть, но хендлеров нет** (Entryway, wardrobe в what_is_in_photo).
- Также отмечены **хендлеры без живых кнопок** (scene_* для экстерьера, show_referral_program, show_statistics из меню).

Этот файл заменяет прежнюю версию `SCREENS_MAP.md`, которая содержала придуманную структуру.
