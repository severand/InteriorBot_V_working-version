# 🩺 TROUBLESHOOTING - Диагностика и решение проблем

**Назначение:** Быстро найти причину проблемы и исправить её.  
**Фокус:** реальные кейсы InteriorBot, без теории.  
**Последнее обновление:** December 12, 2025  

---

## 📋 Содержание

1. [Методика поиска проблем](#методика-поиска-проблем)
2. [Типичные симптомы и решения](#типичные-симптомы-и-решения)
3. [Проблемы с генерацией (Replicate)](#проблемы-с-генерацией-replicate)
4. [Проблемы с платежами (YooKassa)](#проблемы-с-платежами-yookassa)
5. [Проблемы с БД (SQLite)](#проблемы-с-бд-sqlite)
6. [Проблемы с FSM и меню](#проблемы-с-fsm-и-меню)
7. [Чек-лист перед продом](#чек-лист-перед-продом)

---

## 🧭 Методика поиска проблем

### Шаг 1: Зафиксировать симптом

Ответь на вопросы:

```markdown
- Что именно не работает? (команда, кнопка, генерация, оплата)
- Это воспроизводится всегда или иногда?
- У всех пользователей или у одного?
- После какого действия всё ломается?
```

### Шаг 2: Посмотреть логи

```bash
# Локально (если лог в файл)
tail -n 100 bot.log

# Через systemd
journalctl -u interiorbot -n 100 --no-pager

# Через Docker
docker compose logs -n 100 interiorbot
```

Ищи по ключевым словам:

```bash
grep -i "ERROR" bot.log
grep -i "Traceback" bot.log
grep -i "Replicate" bot.log
grep -i "YooKassa" bot.log
```

### Шаг 3: Воспроизвести с тестовым пользователем

- Запусти бота в **debug-режиме** (см. DEVELOPMENT_GUIDE).
- Повтори шаги руками.
- Смотри, какие хендлеры срабатывают и какие данные в state.data/БД.

### Шаг 4: Локализовать модуль

Определи **из какого слоя** проблема:

```markdown
- handlers  → неправильный сценарий / callback_data / FSM
- services  → Replicate или YooKassa
- database  → SQLite, запросы, блокировки
- config    → токены, ключи, ADMIN_IDS
```

---

## ⚠️ Типичные симптомы и решения

### 1. Бот не отвечает на /start

**Симптомы:**
- В Telegram отправляешь `/start`, ничего не происходит.
- Логи пустые или есть ошибка подключения к Telegram.

**Проверки:**

```bash
# 1. Проверка, что бот вообще запущен
ps aux | grep bot/main.py

# 2. Проверка BOT_TOKEN
grep BOT_TOKEN .env

# 3. Прямой запрос в Telegram API
source venv/bin/activate
python - << 'PY'
import os, requests
from dotenv import load_dotenv
load_dotenv()

bot_token = os.getenv('BOT_TOKEN')
print("BOT_TOKEN:", bot_token[:15] + '...')

r = requests.get(f"https://api.telegram.org/bot{bot_token}/getMe")
print(r.status_code, r.text)
PY
```

**Типовые причины и решения:**

```markdown
1) Неправильный BOT_TOKEN
   - Симптом: getMe возвращает 401 / 404
   - Решение: взять токен заново у @BotFather, обновить .env, перезапустить бота.

2) Бот не запущен
   - Симптом: ps aux не показывает bot/main.py
   - Решение: запустить: `python bot/main.py` или `systemctl start interiorbot`.

3) Ошибка при старте
   - Симптом: в логах сразу Traceback при импорте
   - Решение: исправить ошибку (обычно синтаксис или отсутствующая зависимость).
```

---

### 2. Кнопки не работают (callback не обрабатывается)

**Симптомы:**
- При нажатии на inline-кнопку ничего не происходит.
- Внизу Telegram: `Bot hasn't been started` или просто тишина.

**Проверки:**

```markdown
- Смотри логи: приходят ли callback_query события?
- Соответствует ли callback_data тому, что ожидает хендлер?
- Есть ли нужный @router.callback_query с правильным F.data?
- Не перехватывает ли другой хендлер это событие раньше?
```

**Частые ошибки:**

```python
# 1. Ошибка в callback_data
# В кнопке: callback_data="create_designs" (лишняя s)
# В хендлере: F.data == "create_design"

# Решение: синхронизировать строку 1-в-1.

# 2. Отсутствует state в декораторе
@router.callback_query(F.data.startswith("style_"))  # ❌

# Но пользователь в FSM-состоянии choose_style,
# а хендлер объявлен БЕЗ state.

# Лучше так:
@router.callback_query(F.data.startswith("style_"), state=CreationStates.choose_style)  # ✅
```

---

### 3. После навигации появляются новые сообщения вместо редактирования

**Симптомы:**
- Вместо того, чтобы обновлять одно "главное" сообщение, бот шлёт новые сообщения вниз чата.

**Вероятная причина:**
- Где-то вызвано `state.clear()` → потерян `menu_message_id`.

**Как найти:**

```bash
grep -R "state.clear" -n bot/
```

**Правильный паттерн:**

```python
# Для навигации между экранами МЕНЯЕМ ТОЛЬКО СОСТОЯНИЕ FSM
await state.set_state(None)  # ✅ FSM сброшен, menu_message_id сохранён

# Для полного ресета (очистить ВСЁ, включая menu_message_id)
await state.clear()  # ⚠️ Только для /start или жёсткого сброса
```

Смотри подробности в `DEVELOPMENT_RULES.md` и `FSM_GUIDE.md`.

---

### 4. Генерация висит или падает

**Симптомы:**
- После выбора стиля долго "⏳ Генерирую..." и ничего не происходит.
- Или быстро "❌ Generation failed".

**Проверки:**

```bash
grep -i "Replicate" bot.log
grep -i "generate_image" bot.log
```

**Типовые причины:**

```markdown
1) REPLICATE_API_TOKEN неверный или просрочен
   - Ошибка в логах: 401 / 403 от Replicate
   - Решение: обновить токен, проверить в https://replicate.com/account

2) Ошибка сети / timeout
   - Ошибка: asyncio.TimeoutError или httpx.TimeoutException
   - Решение: увеличить таймаут, проверить интернет на сервере.

3) Неподходящая картинка (слишком большая/битая)
   - Ошибка декодирования / обработки
   - Решение: добавить доп. проверку, попросить пользователя отправить другое фото.
```

**Что логировать:**

```python
logger.info(f"Starting generation for user={user_id}, room={room}, style={style}")
logger.debug(f"photo_id={photo_id}")
```

---

### 5. Оплата не подтверждается (check_payment всегда "не оплачено")

**Симптомы:**
- Пользователь оплачивает счёт, но при нажатии "Я оплатил" — всегда сообщение "Оплата не найдена" или "ещё не поступила".

**Проверки:**

```bash
grep -i "check_payment" bot.log
grep -i "YooKassa" bot.log
```

**Частые кейсы:**

```markdown
1) В БД нет pending-платежа
   - Причина: create_payment() не отработал или упал с ошибкой
   - Проверка в SQLite:
     sqlite3 bot.db
     SELECT * FROM payments WHERE status='pending';

2) Не тот payment_id отправляется в YooKassa
   - Проверка: логировать yookassa_payment_id при создании и при проверке

3) YooKassa ещё не подтвердила платёж
   - Решение: подождать несколько секунд и повторно нажать "Я оплатил".

4) Неверные SHOP_ID / SECRET_KEY
   - Симптом: ошибки авторизации в логах при вызове Payment.find_one()
   - Решение: сверить реквизиты в кабинете YooKassa.
```

---

### 6. Ошибки БД: "database is locked" / "unable to open database file"

**Симптомы:**
- Периодические падения с `sqlite3.OperationalError`.

**Проверки:**

```bash
grep -i "database is locked" bot.log
grep -i "unable to open database" bot.log
```

**Типичные причины и решения:**

```markdown
1) Несколько процессов бота работают с одной и той же bot.db
   - Решение: оставить только один процесс (один systemd сервис или один docker-контейнер).

2) Права доступа на файл bot.db
   - Решение:
     sudo chown $USER:$USER bot.db
     sudo chmod 600 bot.db

3) Оборванные WAL/SHM файлы
   - Решение:
     rm -f bot.db-wal bot.db-shm
```

---

## 🧩 Проблемы с генерацией (Replicate)

### Ошибка: `replicate.error.ReplicateError`

**Симптомы:**
- В логах стек-трейс от Replicate.

**Причины:**

```markdown
- Неподдерживаемая модель или версия
- Неверный формат входных данных (image, prompt)
- Превышение квоты / лимитов
```

**Решения:**

```markdown
1) Проверить модель и версию в коде (services/replicate_api.py)
2) Убедиться, что image передаётся как base64 data URL
3) Проверить лимиты и биллинг в кабинете Replicate
```

---

## 💳 Проблемы с платежами (YooKassa)

### Ошибка: `yookassa.exceptions.RequestError`

**Симптомы:**
- В логах: ошибка при вызове Payment.create или Payment.find_one.

**Частые причины:**

```markdown
- Неверный SHOP_ID или SECRET_KEY
- Неправильный формат суммы (строка/float вместо целого)
- Неверный формат валюты (должно быть RUB)
```

**Решения:**

```markdown
1) Проверить .env и config.py
2) Проверить пример из документации YooKassa и сравнить с нашим
3) Включить подробные логи запроса/ответа
```

---

## 🗄 Проблемы с БД (SQLite)

### Симптом: Пользователю не создаётся запись / баланс не меняется

**Проверки:**

```bash
sqlite3 bot.db
.tables
SELECT * FROM users LIMIT 5;
SELECT * FROM payments LIMIT 5;
```

**Типичные баги:**

```markdown
1) Не вызван init_db() на проде
   - Решение: выполнить Database.init_db()

2) Ошибка в SQL запросе (models.py)
   - Симптом: OperationalError в логах
   - Решение: проверить SQL вручную в sqlite3 CLI.

3) Не коммитятся транзакции
   - Решение: убедиться, что в db.py после execute есть commit().
```

---

## 🧩 Проблемы с FSM и меню

### Симптом: Пользователь "застревает" в состоянии

**Признаки:**
- После генерации новые нажатия ведут себя странно.
- В логах FSM state всё ещё `choose_style`.

**Проверка FSM:**

```python
fsm_state = await state.get_state()
logger.warning(f"FSM STATE = {fsm_state}")
```

**Решение:**

```python
# В конце сценария ВСЕГДА вызывать
await state.set_state(None)
```

### Симптом: Кнопки создают новые сообщения вместо редактирования

См. раздел про `state.clear()` выше и `DEVELOPMENT_RULES.md`.

---

## ✅ Чек-лист перед продом

```markdown
- [ ] /start работает стабильно, без ошибок в логах
- [ ] Основной сценарий генерации отработан 10+ раз без таймаутов
- [ ] Платежи проведены в боевом YooKassa (тестовые и реальные)
- [ ] Бэкапы bot.db настроены (cron + проверка восстановления)
- [ ] DEBUG=false, LOG_LEVEL=INFO/ WARNING
- [ ] Ограничен доступ к .env и bot.db
- [ ] systemd или docker-конфиг протестирован на рестарты
- [ ] Админ-аккаунт проверен (ADMIN_IDS действительно работают)
- [ ] Документация прочитана: DEVELOPMENT_GUIDE, ARCHITECTURE, FSM_GUIDE
```

---

**Document Status:** ✅ Complete  
**Last Updated:** December 12, 2025  
**Version:** 2.0 Professional
