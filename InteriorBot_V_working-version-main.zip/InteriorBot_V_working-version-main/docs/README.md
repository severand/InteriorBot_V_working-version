# 🎨 InteriorBot — Telegram-бот для генерации интерьерных дизайнов

> **Production-готовый Telegram-бот для создания интерьерных дизайнов**  
> Powered by Replicate AI (ControlNet) + YooKassa Payments + FSM State Machine

![Статус](https://img.shields.io/badge/статус-production--ready-brightgreen?style=flat-square)  
![Версия](https://img.shields.io/badge/версия-2.0-blue?style=flat-square)  
![Python](https://img.shields.io/badge/python-3.10+-yellow?style=flat-square)  
![Лицензия](https://img.shields.io/badge/лицензия-MIT-green?style=flat-square)  

---

## 🚀 Быстрый старт (5 минут)

### Требования
- Python 3.10+
- Git
- Виртуальное окружение (venv)

### Установка

```bash
# 1. Клонируем репозиторий
git clone https://github.com/severand/InteriorBot_V_working-version.git
cd InteriorBot_V_working-version

# 2. Создаём виртуальное окружение
python -m venv venv
source venv/bin/activate  # Linux/Mac
# или
venv\Scripts\activate  # Windows

# 3. Устанавливаем зависимости
pip install -r requirements.txt

# 4. Создаём .env файл
cp .env.example .env
# Заполняем: BOT_TOKEN, REPLICATE_API_TOKEN, YOOKASSA_SHOP_ID, YOOKASSA_SECRET_KEY

# 5. Инициализируем базу данных
python -c "from bot.database.db import Database; import asyncio; asyncio.run(Database.init_db())"

# 6. Запускаем бота
python bot/main.py
```

---

## ⚙️ Конфигурация

Создайте файл `.env` в корневой папке:

```env
# Telegram
BOT_TOKEN=your_telegram_bot_token
BOT_LINK=@your_bot_username

# Генерация изображений (Replicate)
REPLICATE_API_TOKEN=your_replicate_token

# Платежная система (YooKassa)
YOOKASSA_SHOP_ID=your_shop_id
YOOKASSA_SECRET_KEY=your_secret_key

# Администраторы
ADMIN_IDS=123456789,987654321

# Логирование и отладка
DEBUG=false
LOG_LEVEL=INFO
```

### Где получить ключи

**Токен Telegram:**
- Напишите [@BotFather](https://t.me/botfather)
- Создайте нового бота, скопируйте токен

**Replicate API Token:**
- Зарегистрируйтесь на [replicate.com](https://replicate.com)
- Перейдите в API tokens, создайте новый

**YooKassa credentials:**
- Зарегистрируйтесь на [yookassa.ru](https://yookassa.ru)
- Скопируйте Shop ID и Secret Key из настроек

---

## 📁 Структура проекта

```
InteriorBot/
├── bot/                          # 🤖 Основной код бота
│   ├── main.py                   # Точка входа
│   ├── config.py                 # Загрузка конфига из .env
│   │
│   ├── database/
│   │   ├── db.py                 # Инициализация и запросы к БД
│   │   ├── models.py             # ORM модели (User, Design, Payment, Referral)
│   │   └── .gitignore
│   │
│   ├── handlers/
│   │   ├── user_start.py         # /start, главное меню, навигация
│   │   ├── creation.py           # FSM: фото → комната → стиль → генерация
│   │   ├── payment.py            # Баланс, покупка токенов, YooKassa
│   │   ├── admin.py              # Админ-панель (статистика, рассылки)
│   │   └── referral.py           # Реферальная система
│   │
│   ├── keyboards/
│   │   ├── inline.py             # Inline-кнопки (меню, выбор стиля)
│   │   └── reply.py              # Reply-кнопки (если требуются)
│   │
│   ├── services/
│   │   ├── replicate_api.py      # Обёртка над API генерации Replicate
│   │   ├── payment_api.py        # Интеграция с YooKassa
│   │   └── notifications.py      # Опционально: уведомления
│   │
│   ├── states/
│   │   └── fsm.py                # FSM-состояния (CreationStates)
│   │
│   └── utils/
│       ├── texts.py              # Все текстовые сообщения
│       ├── helpers.py            # Вспомогательные функции
│       └── navigation.py          # Логика редактирования меню (edit_menu)
│
├── docs/                         # 📚 Полная документация
│   ├── MASTER_INDEX.md           # Навигация по документам
│   ├── DEVELOPMENT_GUIDE.md      # Локальная разработка и отладка
│   ├── ARCHITECTURE.md           # Архитектура системы
│   ├── API_REFERENCE.md          # Справочник хендлеров
│   ├── DEPLOYMENT.md             # Production деплой
│   └── TROUBLESHOOTING.md        # Решение проблем
│
├── DEVELOPMENT_RULES.md          # 🚨 Правила разработки (КРИТИЧНО!)
├── FSM_GUIDE.md                  # 🔄 Подробный гайд по FSM
├── ADDITIONAL_FEATURES_SPEC.md   # Roadmap функций
├── REFERRAL_SYSTEM.md            # Механика реферальной системы
├── requirements.txt              # Зависимости
├── .env.example                  # Пример конфига
├── .gitignore                    # Git-игнор правила
├── bot.db                        # SQLite база (генерируется)
└── README.md                     # Этот файл
```

---

## 🏗️ Архитектура системы

### Основная схема

```
┌─────────────────────────────────┐
│   👤 Пользователь Telegram      │
└─────────────┬───────────────────┘
              │
              ▼
┌─────────────────────────────────┐
│   🤖 aiogram 3.x Dispatcher     │
└─────────────┬───────────────────┘
              │
    ┌─────────┼─────────┬──────────┐
    ▼         ▼         ▼          ▼
┌────────┐ ┌────────┐ ┌────────┐ ┌────────┐
│user_   │ │creation│ │payment │ │ admin  │
│start   │ │handler │ │handler │ │handler │
└────────┘ └────────┘ └────────┘ └────────┘
    │         │         │          │
    └─────────┼─────────┼──────────┘
              ▼
       ┌──────────────────┐
       │ FSM (состояния)  │
       │ Keyboards        │
       │ Database (SQLite)│
       │ Services         │
       └─────────┬────────┘
                 │
        ┌────────┼────────┐
        ▼        ▼        ▼
    ┌────────┐ ┌────────┐ ┌────────┐
    │Replicate│ │YooKassa│ │ SQLite │
    │(AI Gen) │ │(Payment)│ │(Data) │
    └────────┘ └────────┘ └────────┘
```

### Поток: Генерация дизайна

```
1. Пользователь нажимает "Создать дизайн"
   ↓ FSM state: waiting_for_photo
   ↓ Бот просит фото

2. Пользователь отправляет фото комнаты
   ↓ Валидация (не альбом, не видео)
   ↓ Сохранение photo_id в FSM
   ↓ FSM state: choose_room
   ↓ Показываем выбор типа комнаты

3. Пользователь выбирает комнату (гостиная, спальня, кухня, офис)
   ↓ Сохранение room в FSM
   ↓ FSM state: choose_style
   ↓ Показываем выбор стиля

4. Пользователь выбирает стиль (модерн, минимализм, скандинавский и т.д.)
   ↓ Проверка баланса (≥ 1 токен)
   ↓ Списание 1 токена
   ↓ Вызов Replicate API (ControlNet)
   ↓ Получение сгенерированного изображения
   ↓ FSM state: None
   ↓ Отправка результата с меню действий
```

### Поток: Оплата

```
1. Пользователь кликает "Купить токены"
   ↓ Показываем пакеты

2. Выбирает пакет (25, 50, 100 токенов)
   ↓ Вызов YooKassa API: create_payment()
   ↓ Сохранение платежа в БД (статус: pending)
   ↓ Отправка ссылки на оплату + кнопка "Проверить"

3. Пользователь платит через YooKassa
   ↓ Банк обрабатывает платёж
   ↓ YooKassa обновляет статус на "succeeded"

4. Пользователь кликает "Я оплатил!"
   ↓ Проверка статуса платежа в YooKassa API
   ↓ Если успешно:
      ├─ Обновление статуса в БД
      ├─ Добавление токенов к балансу
      └─ Показ результата
```

---

## ✨ Основные фишки

### 1. 🎨 Генерация дизайна интерьеров
- Загрузка фото комнаты
- Выбор типа комнаты (4 вида)
- Выбор стиля дизайна (10+ стилей)
- AI-генерация через Replicate (ControlNet + Stable Diffusion)
- 3 бесплатных токена при регистрации

### 2. 💰 Система платежей
- Интеграция с YooKassa
- Поддержка карт, Apple Pay, Google Pay, кошельков
- Пакеты токенов (25, 50, 100)
- Отслеживание баланса в реальном времени
- Проверка статуса оплаты (без вебхука — по запросу)

### 3. 🔗 Реферальная система
- Уникальные реферальные ссылки
- Бонусы за рефералов
- Отслеживание рефов
- Система многоуровневых бонусов

### 4. 🔐 Единое меню (критически важно!)
- **Одно главное сообщение редактируется** при навигации (не создаются новые)
- Экономит место в чате
- Сохраняется `menu_message_id` при всех переходах
- Использует `edit_menu()` для редактирования
- **ПРАВИЛО**: используйте `state.set_state(None)` вместо `state.clear()`

### 5. 📊 Админ-панель
- Статистика пользователей
- Рассылка сообщений
- Управление лимитами генерации
- Ручное управление токенами
- Мониторинг платежей

---

## 🔄 Машина состояний (FSM)

### Состояния

```python
CreationStates
├── waiting_for_photo      # Ожидание фото комнаты
├── choose_room            # Выбор типа комнаты
└── choose_style           # Выбор стиля (запуск генерации)
```

### Диаграмма переходов

```
Нет состояния
    │ (нажимаем "Создать дизайн")
    ▼
waiting_for_photo
    │ (отправляем фото)
    ▼
choose_room
    │ (выбираем комнату)
    ▼
choose_style
    │ (выбираем стиль)
    ▼
Нет состояния (результат готов)
```

### Важные правила FSM

⚠️ **КРИТИЧЕСКИ ВАЖНО:**

```python
# ✅ ПРАВИЛЬНО - при навигации между меню
await state.set_state(None)  # Сбрасывает ТОЛЬКО FSM, сохраняет menu_message_id

# ❌ НЕПРАВИЛЬНО - при навигации!
await state.clear()  # Удалит menu_message_id → бот создаст новые сообщения

# ✅ ПРАВИЛЬНО - полный сброс (команда /start)
await state.clear()  # Полная очистка FSM и данных
```

**Последствия неправильного использования:**
- `state.clear()` при навигации → потеря `menu_message_id`
- Новые сообщения в конце чата вместо редактирования
- Захламление чата

**详细читайте:** [DEVELOPMENT_RULES.md](DEVELOPMENT_RULES.md) и [FSM_GUIDE.md](FSM_GUIDE.md)

---

## 💾 База данных

### Таблица users
```sql
CREATE TABLE users (
    id INTEGER PRIMARY KEY,
    user_id INTEGER UNIQUE NOT NULL,
    username TEXT,
    first_name TEXT,
    balance INTEGER DEFAULT 3,           -- начальный баланс 3 токена
    created_at DATETIME,
    referral_id INTEGER,
    referred_by INTEGER,
    is_active BOOLEAN DEFAULT 1
);
```

### Таблица designs
```sql
CREATE TABLE designs (
    id INTEGER PRIMARY KEY,
    user_id INTEGER NOT NULL,
    photo_id TEXT,                       -- file_id фото
    room_type TEXT,                      -- living_room, bedroom, kitchen, office
    style TEXT,                          -- modern, minimalist, scandinavian и т.д.
    generated_image_url TEXT,            -- ссылка на сгенерированное изображение
    status TEXT,                         -- generating, completed, failed
    created_at DATETIME,
    FOREIGN KEY(user_id) REFERENCES users(id)
);
```

### Таблица payments
```sql
CREATE TABLE payments (
    id INTEGER PRIMARY KEY,
    user_id INTEGER NOT NULL,
    amount REAL,                         -- сумма в рублях
    tokens INTEGER,                      -- сколько токенов покупали
    payment_id TEXT UNIQUE,              -- ID платежа в YooKassa
    status TEXT,                         -- pending, succeeded, cancelled
    created_at DATETIME,
    confirmed_at DATETIME,
    FOREIGN KEY(user_id) REFERENCES users(id)
);
```

### Таблица referrals
```sql
CREATE TABLE referrals (
    id INTEGER PRIMARY KEY,
    user_id INTEGER NOT NULL,
    referred_user_id INTEGER NOT NULL,
    bonus_tokens INTEGER,                -- бонус за реф
    created_at DATETIME,
    FOREIGN KEY(user_id) REFERENCES users(id),
    FOREIGN KEY(referred_user_id) REFERENCES users(id)
);
```

---

## 🛠️ Технологический стек

| Компонент | Технология | Назначение |
|-----------|-----------|----------|
| **Фреймворк** | aiogram 3.x | Telegram bot API |
| **Язык** | Python 3.10+ | Основной язык |
| **БД** | SQLite + aiosqlite | Хранение данных |
| **Генерация** | Replicate API | AI-изображения |
| **Платежи** | YooKassa | Обработка платежей |
| **HTTP** | aiohttp | Асинхронные запросы |
| **Конфиг** | python-dotenv | Переменные окружения |

---

## 📚 Документация

### Навигация

| Документ | Назначение | Время |
|----------|-----------|-------|
| **[DEVELOPMENT_RULES.md](DEVELOPMENT_RULES.md)** | 🚨 Правила разработки (критично!) | 30 мин |
| **[FSM_GUIDE.md](FSM_GUIDE.md)** | 🔄 Подробный гайд по FSM | 1 час |
| **[MASTER_INDEX.md](docs/MASTER_INDEX.md)** | 🏠 Навигация по документам | 5 мин |
| **[DEVELOPMENT_GUIDE.md](docs/DEVELOPMENT_GUIDE.md)** | 💻 Локальная разработка | 30 мин |
| **[ARCHITECTURE.md](docs/ARCHITECTURE.md)** | 🏗️ Архитектура системы | 1 час |
| **[API_REFERENCE.md](docs/API_REFERENCE.md)** | 📖 Справочник хендлеров | 1 час |
| **[DEPLOYMENT.md](DEPLOYMENT.md)** | 🚀 Production деплой | 1 час |
| **[TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md)** | 🐛 Решение проблем | 30 мин |
| **[REFERRAL_SYSTEM.md](REFERRAL_SYSTEM.md)** | 🎁 Реферальная система | 20 мин |
| **[ADDITIONAL_FEATURES_SPEC.md](ADDITIONAL_FEATURES_SPEC.md)** | 🗺️ Roadmap функций | 30 мин |

### Рекомендуемый порядок чтения

**День 1: Настройка и понимание**
1. Этот README (5 мин)
2. [DEVELOPMENT_GUIDE.md](docs/DEVELOPMENT_GUIDE.md) (30 мин)
3. [ARCHITECTURE.md](docs/ARCHITECTURE.md) (1 час)

**День 2: Глубокое понимание**
1. [DEVELOPMENT_RULES.md](DEVELOPMENT_RULES.md) (30 мин) ⚠️ **КРИТИЧНО**
2. [FSM_GUIDE.md](FSM_GUIDE.md) (1 час)
3. Начинаем писать код!

**День 3+: Production**
1. [DEPLOYMENT.md](DEPLOYMENT.md) (1 час)
2. [TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md) (по мере необходимости)
3. Деплоим в production

---

## ⚠️ Критические паттерны и правила

### 1️⃣ Единое меню (ОБЯЗАТЕЛЬНО!)

```python
# ✅ ВСЕ переходы между экранами должны использовать edit_menu()
from bot.utils.navigation import edit_menu

await edit_menu(
    callback=callback,
    state=state,
    text="Текст меню",
    keyboard=get_keyboard()
)
```

### 2️⃣ Навигация между меню

```python
# ✅ При переходе между экранами (главное меню → профиль → назад)
await state.set_state(None)  # ТОЛЬКО сбрасываем FSM-состояние

# ❌ НИКОГДА при навигации!
await state.clear()  # Потеряется menu_message_id!
```

### 3️⃣ FSM-состояния (только для сценариев)

```python
# ✅ Правильное использование FSM
@router.message(F.photo, state=CreationStates.waiting_for_photo)
async def photo_uploaded(message: Message, state: FSMContext):
    # Валидация
    # Сохранение в FSM
    await state.update_data(photo_id=photo.file_id)
    # Переход в следующее состояние
    await state.set_state(CreationStates.choose_room)
```

### 4️⃣ Работа с YooKassa (без вебхука)

```python
# YooKassa workflow:
# 1. Создаём платёж: payment_id + payment_url
# 2. Сохраняем payment (status: pending) в БД
# 3. Отправляем пользователю ссылку
# 4. Пользователь оплачивает
# 5. Пользователь нажимает "Проверить" в боте
# 6. Проверяем статус в YooKassa API
# 7. Если succeeded → обновляем БД и добавляем токены

# Важно: НЕ используем вебхук (по заданию)
# Поэтому статус проверяется ТОЛЬКО по запросу пользователя
```

### 5️⃣ Обработка ошибок

```python
# При редактировании меню может быть ошибка:
# - "message is not modified" → текст не изменился (не ошибка)
# - "message to edit not found" → сообщение удалено пользователем

try:
    await callback.message.edit_text(text, reply_markup=kb)
except TelegramBadRequest as e:
    if "not modified" in str(e).lower():
        pass  # OK
    elif "not found" in str(e).lower():
        # Создаём новое сообщение
        await message.answer(text, reply_markup=kb)
```

---

## 🧪 Тестирование

```bash
# Проверка токена
python check_token.py

# Тест Replicate API
python test_replicate.py

# Тест YooKassa API  
python test_yookassa.py

# Список доступных моделей
python list_models.py

# Поиск конкретной модели
python find_model.py
```

### Чеклист тестирования

- [ ] Бот запускается без ошибок
- [ ] Команда /start работает
- [ ] Главное меню отображается
- [ ] Загрузка фото работает
- [ ] FSM-переходы корректны
- [ ] Генерация дизайна завершается
- [ ] Ссылка на оплату генерируется
- [ ] Баланс обновляется
- [ ] Админ-панель доступна
- [ ] Реферальные ссылки работают

---

## 🚀 Деплой на VPS

### Ubuntu 20.04+

```bash
# 1. SSH на сервер
ssh user@your_vps_ip

# 2. Клонируем репозиторий
git clone https://github.com/severand/InteriorBot_V_working-version.git
cd InteriorBot_V_working-version

# 3. Python и зависимости
sudo apt-get update
sudo apt-get install python3.10 python3.10-venv
python3.10 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# 4. Конфиг
cp .env.example .env
nano .env  # заполняем credentials

# 5. БД
python -c "from bot.database.db import Database; import asyncio; asyncio.run(Database.init_db())"

# 6. systemd сервис (подробно в DEPLOYMENT.md)
sudo nano /etc/systemd/system/interiorbot.service
# Добавляем конфиг

# 7. Запуск
sudo systemctl start interiorbot
sudo systemctl enable interiorbot
sudo journalctl -u interiorbot -f
```

**Полный гайд:** [DEPLOYMENT.md](DEPLOYMENT.md)

---

## 🐛 Решение проблем

### Бот не запускается
```
✓ Проверьте BOT_TOKEN в .env
✓ Проверьте интернет
✓ Запустите в verbose: python bot/main.py -v
✓ Смотрите bot.log
```

### Ошибка генерации
```
✓ Проверьте REPLICATE_API_TOKEN
✓ Проверьте баланс токенов в Replicate
✓ Проверьте размер фото (< 10MB)
✓ Запустите python test_replicate.py
```

### Проблемы с оплатой
```
✓ Проверьте YOOKASSA_SHOP_ID & SECRET_KEY
✓ Проверьте режим (test/production)
✓ Смотрите статус в YooKassa dashboard
✓ Запустите python test_yookassa.py
```

### Проблемы с меню
```
✓ Проверьте используется ли edit_menu() везде
✓ Проверьте не используется ли state.clear() при навигации
✓ Смотрите логи (добавьте logger.warning())
✓ Читайте DEVELOPMENT_RULES.md
```

**Полный гайд:** [TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md)

---

## 📊 Статистика проекта

- **Строк кода:** 5000+
- **Строк документации:** 9000+
- **Хендлеры:** 5+ (5 основных файлов)
- **Callback patterns:** 30+
- **Модели БД:** 4 (User, Design, Payment, Referral)
- **FSM-состояния:** 3 основных
- **API интеграции:** 3 (Telegram, Replicate, YooKassa)
- **Функции:** 50+

---

## ⚡ Производительность

- **Время ответа бота:** < 100ms
- **Генерация дизайна:** 30-60 сек (зависит от Replicate)
- **Запрос к БД:** < 50ms
- **Обработка платежа:** < 2 сек
- **Одновременные пользователи:** 100+

---

## 🔒 Безопасность

- ✅ Все ключи в .env (не в коде)
- ✅ Валидация всех входных данных
- ✅ Защита от SQL-инъекций (параметризованные запросы)
- ✅ Rate limiting на API
- ✅ HTTPS для всех внешних запросов
- ✅ Контроль доступа (админы)
- ✅ Логирование критических операций

---

## 🤝 Контрибьютинг

1. Прочитайте [DEVELOPMENT_RULES.md](DEVELOPMENT_RULES.md)
2. Создайте ветку: `git checkout -b feature/your-feature`
3. Коммитьте ясно: `git commit -m "feat: добавил новую фишку"`
4. Пушьте: `git push origin feature/your-feature`
5. Откройте Pull Request

### Код-стайл
- Python: PEP 8
- Длина строки: 100 символов
- Type hints: обязательно
- Docstrings: Google style
- Комментарии: ясные и краткие

---

## 📞 Поддержка

- **Issues:** [GitHub Issues](https://github.com/severand/InteriorBot_V_working-version/issues)
- **Документация:** Папка `docs/`
- **Telegram:** [@BotFather](https://t.me/botfather) (для Telegram вопросов)

---

## 📄 Лицензия

MIT License — см. файл LICENSE

---

## 📈 Статус проекта

| Параметр | Значение |
|----------|----------|
| **Статус** | ✅ Production-Ready |
| **Версия** | 2.0 |
| **Последнее обновление** | 22 декабря 2025 |
| **Поддержка** | Активная |
| **Совместимость** | Python 3.10+ |

---

## 🙏 Спасибо

- **aiogram** — лучший фреймворк для Telegram
- **Replicate** — удивительная генерация изображений
- **YooKassa** — надёжная платёжная система
- **Python Community** — великолепные библиотеки

---

## 🎯 Готовы к запуску?

**👉 Начните с:** [DEVELOPMENT_GUIDE.md](docs/DEVELOPMENT_GUIDE.md)

**Главное правило:** Прочитайте [DEVELOPMENT_RULES.md](DEVELOPMENT_RULES.md) перед первым коммитом! ⚠️

---

*Made with ❤️ for interior lovers and developers*
